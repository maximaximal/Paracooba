#include "internal.hpp"

namespace CaDiCaL {

int Internal::most_occurring_literal () {
  init_noccs ();
  for (const auto & c : clauses)
    if (!c->redundant)
      for (const auto & lit : *c)
        if (active (lit))
          noccs (lit)++;
  int64_t max_noccs = 0;
  int res = 0;

  for (int idx = 1; idx <= max_var; idx++) {
    if (!active (idx) || assumed(idx) || assumed(-idx)) continue;
    assert (!val (idx));
    for (int sign = -1; sign <= 1; sign += 2) {
      const int lit = sign * idx;
      if (!active(lit))
        continue;
      int64_t tmp = noccs(lit);
      if (tmp <= max_noccs)
        continue;
      max_noccs = tmp;
      res = lit;
    }
  }
  LOG ("maximum occurrence %" PRId64 " of literal %d", max_noccs, res);
  reset_noccs ();
  return res;
}

}
